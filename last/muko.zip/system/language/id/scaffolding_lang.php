<?php

$lang['scaff_view_records'] = 'Lihat Record';
$lang['scaff_create_record'] = 'Buat Record Baru';
$lang['scaff_add'] = 'Tambah Data';
$lang['scaff_view'] = 'Lihat Data';
$lang['scaff_edit'] = 'Sunting';
$lang['scaff_delete'] = 'Hapus';
$lang['scaff_view_all'] = 'Lihat Semua';
$lang['scaff_yes'] = 'Ya';
$lang['scaff_no'] = 'Tidak';
$lang['scaff_no_data'] = 'Masih belum ada data untuk tabel ini.';
$lang['scaff_del_confirm'] = 'Apakah anda yakin untuk menghapus baris ini:';
?>