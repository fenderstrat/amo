<div class="menu-kiri">
	<h3>Menu</h3>
	<ul>
		<li><a href="#">beranda</a></li>
		<li><a href="#">profil</a></li>
		<li><a href="#">berita</a></li>
		<li><a href="#">daftar calon tetap</a></li>
		<li><a href="#">kontak</a></li>
	</ul>
</div>