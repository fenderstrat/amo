

<div class="news">

	<div class="judul">
		<h2 class="post-judul"><?php echo $artikel->judul; ?>
			<span class="meta-date"><?php echo $artikel->tanggal; ?></span>
		</h2>
	</div>
	
	<div class="post">
		<?php echo $artikel->artikel; ?>
	</div>

</div>

<div class="clear"></div>

	