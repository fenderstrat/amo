<div class="sidebar">

	<div class="widget">
		<img src="<?php echo base_url().'assets/template/' ?>image/iklan.gif" alt="FOTO IKLAN" width="300">
	</div>
	
	<div class="widget">
		<a href="#"><img src="<?php echo base_url().'assets/template/' ?>image/daftarpartai.png"></a>
	</div>
	<div class="widget">
		<div class="judul">
			<h3 class="juduls">DPT online</h3>
			<div class="clear"></div>
		</div>
		<a href="http://data.kpu.go.id/dpt.php"><img src="<?php echo base_url().'assets/template/' ?>image/dpt.png" width="300"></a>
	</div>
	<div class="widget">
		<div class="judul">
			<h3 class="juduls">datacenter kpu</h3>
			<div class="clear"></div>
		</div>
		<a href="http://www.kpu.go.id/"><img src="<?php echo base_url().'assets/template/' ?>image/kpu-pusat.png" width="300"></a>
		<p></p>
		<a href="http://silog-data.kpu.go.id/"><img src="<?php echo base_url().'assets/template/' ?>image/silog.png" width="300"></a>
	</div>
</div>
<div class="clear"></div>