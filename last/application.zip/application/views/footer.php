<div class="footer-wrapper">
	<div class="footer">
		<div class="copyright">
			<p>&copy; 2014 KPU Muko Muko</p>
		</div>
		<div class="alamat">
			<p>Jl. Soekarno-Hatta No. 175 Mukomuko 38365</p>
			<p>Telp / Fax 0737 71096</p>
			<p>Email: kpukabmukomuko@gmail.com <p/>
		</div>
		<div class="clear"></div>
	</div>
</div>

</body>
</html>